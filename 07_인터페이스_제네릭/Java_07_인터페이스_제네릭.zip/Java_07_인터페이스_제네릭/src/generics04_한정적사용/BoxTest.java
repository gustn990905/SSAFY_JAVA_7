package generics04_한정적사용;


//우리가 직접 넣을 것을 지정한 박스
//숫자만 되도록 제한 걸기
class Box<T extends Number> {
	private T obj;
	
	public T getObj() {
		return obj;
	}
	
	public void setObj(T obj) {
		this.obj = obj;
	}
}

public class BoxTest {

	public static void main(String[] args) {
		//지금 정의하기를 숫자관려으로만 하기로 했으니 아래는 안되는게 맞음
//		Box<String> box = new Box<>();
		//아래는 숫자관련이니 가넝
		Box<Integer> box2 = new Box<>();
		Box<Double> box3 = new Box<>();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
