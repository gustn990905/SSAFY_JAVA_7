package generics02_generics_box;


//우리가 직접 넣을 것을 지정한 박스
class Box<T> {
	private T obj;
	
	public T getObj() {
		return obj;
	}
	
	public void setObj(T obj) {
		this.obj = obj;
	}
}

public class BoxTest {

	public static void main(String[] args) {
//		Box box = new Box(); //Object 자동으로 들어가는데 -> 비권장 그자체
		
		Box<String> stringBox1 = new Box<String>();
		Box<String> stringBox2 = new Box<>(); //생성자 쪽 꺾쇠 안은 생략 가능
//		Box<> stringBox3 = new Box<String>(); //선언부 쪽 꺾쇠 안은 생략 불가능
		
		stringBox1.setObj("안녕하세요");
//		stringBox2.setObj(100);	//문자열 박스인데 숫자를 넣을려고 해?
		
		//넣을 떄는 쪼끔 귀찮을지몰라 해당 자료타입만 넣을 수 있으니...
		//꺼내어 쓸때는 편하다.
		stringBox1.getObj(); //요기있는 내용물은 무조건 String이야
		
		//////////////////////////////////////////////////////////////
//		Wrapper 클래스
		//기초자료형 -> 참조자료형
//		boolean Boolean
//		long Long
//		int Integer
//		char Character
//		8가지
		
		
		
		int i1 = 11; //객체인가? X
		Integer i2 = 10; //객체인가? O //AutoBoxing
		Integer i3 = Integer.valueOf(100); //객체인가? O Boxing
		
		
		int i4 = i3; //객체인가? X AutoUnboxing;
		int i5 = i3.intValue(); //객체인가? X Unboxing;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
