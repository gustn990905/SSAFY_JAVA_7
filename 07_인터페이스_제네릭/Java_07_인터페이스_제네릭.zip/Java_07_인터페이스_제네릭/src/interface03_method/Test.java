package interface03_method;

public class Test {
	public static void main(String[] args) {
//		MyClass1 c = new MyClass1();
//		
//		c.method1();
//		c.method2();
		
		MyClass3 c = new MyClass3();
		
		c.method3();
		
		MyInterface2.method4();
		
		
		
		
		
		
		
		
		
		
	}
}
