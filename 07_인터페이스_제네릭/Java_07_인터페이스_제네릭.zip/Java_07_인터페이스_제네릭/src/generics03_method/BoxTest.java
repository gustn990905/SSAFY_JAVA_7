package generics03_method;


//우리가 직접 넣을 것을 지정한 박스
class Box<T> {
	private T obj;
	
	public T getObj() {
		return obj;
	}
	
	public void setObj(T obj) {
		this.obj = obj;
	}
	
	//메서드 만을 위해서 제네릭 지정을 할 수도 있다.
	public <A> void printClassName(A item) {
		System.out.println(item.getClass().getName());
	}
	
	
}

public class BoxTest {

	public static void main(String[] args) {
		Box<Integer> box = new Box<>();
		box.printClassName("String");
		box.printClassName(12.5);
		box.<Long>printClassName(1000L);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
