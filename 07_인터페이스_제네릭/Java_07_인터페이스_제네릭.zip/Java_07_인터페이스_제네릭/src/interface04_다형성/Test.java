package interface04_다형성;

public class Test {
	public static void main(String[] args) {
		KFoodChef k = new KFoodChef();
		k.cook();
		
		//참조타입으로 Chef 로 참조할 수 있음
		Chef c = new KFoodChef();
		c.cook(); //동적바인딩
		
		Chef c2 = new Chef() {

			@Override
			public void cook() {
				// TODO Auto-generated method stub
				
			}
			
		};
	}
}
