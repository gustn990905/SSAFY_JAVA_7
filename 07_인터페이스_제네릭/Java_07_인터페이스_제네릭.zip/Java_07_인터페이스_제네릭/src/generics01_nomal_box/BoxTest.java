package generics01_nomal_box;

import interface03_method.MyClass1;

//아무거나 넣을 수 있는 만능 박스
class Box {
	private Object obj;

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}
}

public class BoxTest {

	public static void main(String[] args) {
		Box box = new Box(); // Box안에 obj라고 하는 필드에는 무엇이든지 저장할 수 있다!
		box.setObj("문자열");
		System.out.println(box.getObj());

		box.setObj(1000);
		System.out.println(box.getObj());

		///////////////////////////
		// 넣을 떄는 그냥 냅다 넣고 아주 좋았어!
		// 꺼내서 사용하려고 했을때는.....
		if (box.getObj() instanceof String st) {
			System.out.println("문자열 관련된 무엇인가 작업을 할 수 있다.");
		} else if (box.getObj() instanceof Integer i) {
			System.out.println("정수 관련된 무엇인가 작업을 할 수 있다.");
		} else if (box.getObj() instanceof MyClass1 mc) {
			System.out.println("MyClass 관련 작업을 수행할 수 있다.");
		} else {
			System.out.println("아무것도 아닐때 할 작업을 수행할 수 있다.");
		}

	}

}
