package generics05_와일드카드;


//우리가 직접 넣을 것을 지정한 박스
//숫자만 되도록 제한 걸기
class Box<T> {
	private T obj;
	
	public T getObj() {
		return obj;
	}
	
	public void setObj(T obj) {
		this.obj = obj;
	}
}


class Parent {
	
}

class Child extends Parent{
	
}

class GrandChild extends Child {
	
}








public class BoxTest {

	public static void main(String[] args) {
		
		Box<?> box1 = new Box<Integer>();
		//Ineteger 포함한 상속받고 있는 클래스들만 가능
		Box<? extends Integer> box2 = new Box<>(); 
		
//		box2.setObj(new Object());
		
		//Double을 포함한 상위 클래스들만 가능
		Box<? super Double> box3 = new Box<>();
		box3.setObj(null);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
